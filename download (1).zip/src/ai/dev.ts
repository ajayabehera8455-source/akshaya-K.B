import { config } from 'dotenv';
config();

import '@/ai/flows/generate-mango-recipe.ts';