'use server';
/**
 * @fileOverview An AI agent that generates personalized mango recipes based on user preferences.
 *
 * - generateMangoRecipe - A function that handles the mango recipe generation process.
 * - GenerateMangoRecipeInput - The input type for the generateMangoRecipe function.
 * - GenerateMangoRecipeOutput - The return type for the generateMangoRecipe function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateMangoRecipeInputSchema = z.object({
  ingredients: z
    .array(z.string())
    .optional()
    .describe('A list of ingredients the user has on hand.'),
  cuisinePreference: z
    .string()
    .optional()
    .describe('The user\u2019s preferred cuisine style (e.g., "Thai", "Mediterranean").'),
});
export type GenerateMangoRecipeInput = z.infer<typeof GenerateMangoRecipeInputSchema>;

const GenerateMangoRecipeOutputSchema = z.object({
  recipeName: z.string().describe('The name of the generated recipe.'),
  description: z.string().describe('A short description of the recipe.'),
  ingredients: z
    .array(z.string())
    .describe('A list of all ingredients required for the recipe.'),
  instructions: z
    .array(z.string())
    .describe('Step-by-step instructions to prepare the recipe.'),
  prepTime: z.string().describe('Estimated preparation time for the recipe (e.g., "15 minutes").'),
  cookTime: z.string().describe('Estimated cooking time for the recipe (e.g., "30 minutes").'),
  servings: z.string().describe('The number of servings the recipe yields (e.g., "4").'),
});
export type GenerateMangoRecipeOutput = z.infer<typeof GenerateMangoRecipeOutputSchema>;

export async function generateMangoRecipe(
  input: GenerateMangoRecipeInput
): Promise<GenerateMangoRecipeOutput> {
  return generateMangoRecipeFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateMangoRecipePrompt',
  input: {schema: GenerateMangoRecipeInputSchema},
  output: {schema: GenerateMangoRecipeOutputSchema},
  prompt: `You are a world-renowned chef specializing in innovative and delicious recipes featuring fresh, premium mangos, specifically 'MangoBliss' mangos.
Your task is to create a unique recipe that highlights the exquisite taste of MangoBliss mangos, based on the user's provided preferences.

User Preferences:
{{#if ingredients}}
Ingredients on hand: {{{ingredients}}}
{{/if}}
{{#if cuisinePreference}}
Cuisine preference: {{{cuisinePreference}}}
{{/if}}

Ensure the recipe prominently features MangoBliss mangos as a key ingredient.
The recipe should be easy to follow and delicious. The output should be a JSON object with the following fields: recipeName, description, ingredients (as an array of strings), instructions (as an array of strings), prepTime, cookTime, and servings.`,
});

const generateMangoRecipeFlow = ai.defineFlow(
  {
    name: 'generateMangoRecipeFlow',
    inputSchema: GenerateMangoRecipeInputSchema,
    outputSchema: GenerateMangoRecipeOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
